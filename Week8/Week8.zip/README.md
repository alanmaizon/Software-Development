# Week 8 - Software Development

## Lab 1 – Print a Grid:

We declare rows and cols;
Outer loop will run for the number of rows (10)
i will be the instance variable to count computed rows
And to close the loop we need to close the nested inner one:
Inner loop prints the dash 10 columns per row
j will act as instance variable to count computed dashes (columns)
System.out.println() will print the row 10 times

file: `lab1.java`

## Lab 2 – Average of 4-Year Course:

Import Scanner and declare input
Declare class variables: years, total, and totalSum
User enters 5 results for each year (can incorporate checking parameters)
Compute yearSum for each year
Compute yearAvg for the current year
Accumulate into totalSum
Compute totalAvg after the loop

file: `lab2.java`