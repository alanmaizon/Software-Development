# Week 10 - Software Development

## Lab – String App

### Objective

Create an instantiable class that returns the details of an array of numbers. 

The class should contain 3 methods:

-1 method that accepts as a parameter an array of integers. This method should also calculate the sum of the array and the max value in the array
-1 method that returns the max
-1 method that returns the sum

### Find attached the instantiable `Main.java` and the instance `Test.java`